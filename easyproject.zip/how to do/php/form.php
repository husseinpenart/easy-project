<?php 
  $name = 'name';
  $number = 'number';
  $lastname= 'lastname';
  $password= 'password';
  $color = 'color';
  $email = 'email';

$servername = "localhost";
$name = "name";
$lastname = "lastname";
$password = "";
$number = "";
$color= "";
$email = "";
$website = "";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>information page</title>
</head>

<body>
    <?php

  $conn = new mysqli($servername, $name, $lastname, $color, $email, $password, $number);
  if($conn->connect_error){
      die("Connection Failed" . $conn->connect_error);
  }else{
      echo "Connection Made Successfuly";
  }

///MySQLi Procedural example
// $servername = "localhost";
// $username = "username";
// $password = "password";

// // Create connection
// $conn = mysqli_connect($servername, $username, $password);

// // Check connection
// if (!$conn) {
//   die("Connection failed: " . mysqli_connect_error());
// }
// echo "Connected successfully";
// 
//(PDO ) EXAMPLE

// $servername = "localhost";
// $username = "username";
// $password = "password";

// try {
//   $conn = new PDO("mysql:host=$servername;dbname=myDB", $username, $password);
//   // set the PDO error mode to exception
//   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//   echo "Connected successfully";
// } catch(PDOException $e) {
//   echo "Connection failed: " . $e->getMessage();
// }

  echo"Hello" . htmlspecialchars(($_POST['name']));
   echo"Your last name is :" . htmlspecialchars(($_POST['lastname']));
   echo "Your E-mail is:" . htmlspecialchars($_POST['email']);
   echo "Your website link is :" . htmlspecialchars($_POST['website']);
   echo "Your password is :". (int)$_POST['password'];
   echo "This is Your Logo: ". imagepng($_POST['upload']);
   echo " Your favorite color is :" .htmlspecialchars($_POST['color']);
   echo "Your phone number is:". (int)$_POST['number'];

if($_SERVER["REQEST_METHOD"] == "POST"){
    $name = $_POST['name'];
    if(empty($name)){
        echo "Your $name field is empty";
    }else{
        echo $name;
    }
    $email = $_POST['email'];
    if(empty($email)){
       echo "Your $email is Empty or incorrect";

    }else{
        echo "Your email is $email";
    };
    $lastname = $_POST['lastname'];
    if(empty($lastname)){
        echo "Your $lastname is empty or incorrect";
    }else{
          echo "Your LastName is $lastname";
    }
    $password = $_POST['password'];
    if(empty($password)){
        echo "your $password is empty or incorrect";
    }else{
        echo "Your password is $password";
    }
    $color = $_POST['color'];
    if (empty($color)){
        echo "Your $color is empty or incorrect";
    }else{
        echo "Your favorite color is $color";
    }
    $number = $_POST['number'];
    if (empty($number)){
        echo "Your $number is empty or in correct";
    }else{
        echo "Your number is : $number";
    }
    
}


?>
</body>

</html>