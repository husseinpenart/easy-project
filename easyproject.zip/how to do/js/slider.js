var slideIndex = 1;
showSlides(slideIndex);

// next and prev controls
function Slides(n) {
    showSlides(slideIndex += n);

}
// Thumbnails Image controll

function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("slideimg")
    var Dots = document.getElementsByClassName("dots")
    var captionText = document.getElementById("caption")
    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"
    }
    for (i = 0; i < Dots.length; i++) {
        Dots[i].className = Dots[i].className.replace("active", "")

    }
    slides[slideIndex - 1].style.display = "block";
    Dots[slideIndex - 1].className += "active";
    captionText.innerHTML = Dots[slideIndex - 1].alt;
}