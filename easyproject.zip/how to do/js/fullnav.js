
function openNav() {
    document.getElementById("Nav").style.width = "100%";
  }
  
  function closeNav() {
    document.getElementById("Nav").style.width = "0%";
  }
  // top to down function 
// function openNav() {
//   document.getElementById("Nav").style.height = "100%";
// }

// function closeNav() {
//   document.getElementById("Nav").style.height = "0%";
// }